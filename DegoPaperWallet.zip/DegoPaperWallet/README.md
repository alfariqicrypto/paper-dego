# paper-turtle

**TurtleCoin Paper Wallet Generator**

https://turtlecoin.lol/wallet

## LICENSE

This Project is licensed under AGPL v3.0.

```
// Copyright (c) 2018, The TurtleCoin Developers
//
// Please see the included LICENSE file for more information.
```